
import os
import sys
import subprocess
import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

APP_TITLE = "Drone Live Broadcast (Windows)"
FFMPEG_NAMES = ["ffmpeg.exe", "ffmpeg"]

ffmpeg_proc = None
preview_proc = None

def find_ffmpeg():
    # Look in current folder first, then PATH
    here = os.path.dirname(os.path.abspath(__file__))
    for name in FFMPEG_NAMES:
        p = os.path.join(here, name)
        if os.path.exists(p):
            return p
    # PATH
    for path in os.environ.get("PATH","").split(os.pathsep):
        p = os.path.join(path, "ffmpeg.exe")
        if os.path.exists(p):
            return p
        p2 = os.path.join(path, "ffmpeg")
        if os.path.exists(p2):
            return p2
    return None

def browse_ffmpeg():
    path = filedialog.askopenfilename(title="Locate ffmpeg.exe", filetypes=[("ffmpeg","ffmpeg.exe"),("All","*.*")])
    if path:
        ffmpeg_var.set(path)

def start_stream():
    global ffmpeg_proc
    if ffmpeg_proc and ffmpeg_proc.poll() is None:
        log("Streaming already running.")
        return

    src = rtsp_var.get().strip()
    dst = rtmp_var.get().strip()
    if not src or not dst:
        messagebox.showerror("Missing", "Please enter both RTSP (source) and RTMP (destination) URLs.")
        return

    ff = ffmpeg_var.get().strip() or find_ffmpeg()
    if not ff or not os.path.exists(ff):
        messagebox.showerror("ffmpeg not found", "ffmpeg.exe not found. Please download from ffmpeg.org and place ffmpeg.exe next to this app or set the path below.")
        return

    # Basic ffmpeg pipeline: copy video if possible else transcode to h264+aac
    cmd = [
        ff, "-re", "-i", src,
        "-c:v", "libx264", "-preset", "veryfast", "-tune", "zerolatency",
        "-c:a", "aac", "-b:a", "128k",
        "-f", "flv", dst
    ]
    log("Starting stream...")
    log(" ".join(cmd))
    try:
        ffmpeg_proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        threading.Thread(target=pump_logs, args=(ffmpeg_proc.stdout,), daemon=True).start()
        status_var.set("LIVE")
    except Exception as e:
        messagebox.showerror("Error", str(e))

def stop_stream():
    global ffmpeg_proc
    if ffmpeg_proc and ffmpeg_proc.poll() is None:
        log("Stopping stream...")
        ffmpeg_proc.terminate()
        try:
            ffmpeg_proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            ffmpeg_proc.kill()
        status_var.set("IDLE")
    else:
        log("No active stream.")

def pump_logs(pipe):
    for line in pipe:
        log(line.rstrip())

def log(msg):
    console.configure(state="normal")
    console.insert("end", msg + "\n")
    console.see("end")
    console.configure(state="disabled")

def start_preview():
    global preview_proc
    if preview_proc and preview_proc.poll() is None:
        log("Preview already running.")
        return
    src = rtsp_var.get().strip()
    if not src:
        messagebox.showerror("Missing", "Please enter RTSP (source) URL.")
        return
    # Attempt to preview via ffplay (part of ffmpeg)
    ff = ffmpeg_var.get().strip() or find_ffmpeg()
    if ff:
        ffplay = ff.replace("ffmpeg.exe", "ffplay.exe").replace("ffmpeg", "ffplay")
    else:
        ffplay = None

    if not ffplay or not os.path.exists(ffplay):
        messagebox.showinfo("ffplay not found", "ffplay.exe not found. Preview will open using VLC if installed, otherwise please install VLC or use ffplay.")
        # Try VLC
        vlc_paths = [
            r"C:\Program Files\VideoLAN\VLC\vlc.exe",
            r"C:\Program Files (x86)\VideoLAN\VLC\vlc.exe"
        ]
        vlc = None
        for p in vlc_paths:
            if os.path.exists(p):
                vlc = p
                break
        if vlc:
            preview_proc = subprocess.Popen([vlc, src])
            log("Opening VLC preview...")
            return
        else:
            messagebox.showerror("Preview tool missing", "Neither ffplay nor VLC found. Install one to use Live View preview.")
            return
    else:
        log("Opening ffplay preview...")
        preview_proc = subprocess.Popen([ffplay, "-fflags", "nobuffer", "-flags", "low_delay", "-flags2", "fast", src])

def stop_preview():
    global preview_proc
    if preview_proc and preview_proc.poll() is None:
        log("Stopping preview...")
        preview_proc.terminate()
        try:
            preview_proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            preview_proc.kill()
    else:
        log("No active preview.")

def hdmi_out():
    # Simple instruction dialog; actual HDMI out is handled by Windows display settings and preview window fullscreen.
    messagebox.showinfo("HDMI OUT", "Connect your PC to an external monitor via HDMI. Use Live View (ffplay/VLC) and press 'F' in VLC or use 'f' in ffplay to toggle fullscreen on the external display.")

def save_config():
    cfg = {
        "rtsp": rtsp_var.get(),
        "rtmp": rtmp_var.get(),
        "ffmpeg": ffmpeg_var.get()
    }
    with open("config.json","w",encoding="utf-8") as f:
        f.write(__import__("json").dumps(cfg, indent=2))
    log("Saved config.json.")

def load_config():
    try:
        import json, io
        with open("config.json","r",encoding="utf-8") as f:
            cfg = json.load(f)
        rtsp_var.set(cfg.get("rtsp",""))
        rtmp_var.set(cfg.get("rtmp",""))
        ffmpeg_var.set(cfg.get("ffmpeg",""))
        log("Loaded config.json.")
    except Exception:
        pass

root = tk.Tk()
root.title(APP_TITLE)
root.geometry("900x540")

style = ttk.Style()
try:
    style.theme_use("clam")
except Exception:
    pass

main = ttk.Frame(root, padding=10)
main.pack(fill="both", expand=True)

title = ttk.Label(main, text="ආසල මහ පෙරහැර මංගල්‍යය 2025 — Drone Live Broadcast", font=("Segoe UI", 14, "bold"))
title.pack(pady=(0,8))

frm = ttk.Frame(main)
frm.pack(fill="both", expand=True)

# Left panel
left = ttk.Frame(frm)
left.pack(side="left", fill="y", padx=(0,10))

ttk.Label(left, text="Server Cloud Console").pack(anchor="w")
console = tk.Text(left, width=48, height=20, state="disabled")
console.pack()

btns = ttk.Frame(left)
btns.pack(pady=8, fill="x")
start_btn = ttk.Button(btns, text="Start Stream", command=start_stream)
start_btn.pack(side="left", expand=True, fill="x", padx=(0,6))
stop_btn = ttk.Button(btns, text="Stop Stream", command=stop_stream)
stop_btn.pack(side="left", expand=True, fill="x")

ttk.Label(left, text="Status:").pack(anchor="w", pady=(6,0))
status_var = tk.StringVar(value="IDLE")
ttk.Label(left, textvariable=status_var, foreground="green").pack(anchor="w")

# Right panel
right = ttk.Frame(frm)
right.pack(side="left", fill="both", expand=True)

# Inputs
inputs = ttk.Frame(right)
inputs.pack(fill="x", pady=(0,10))

rtsp_var = tk.StringVar()
rtmp_var = tk.StringVar()
ffmpeg_var = tk.StringVar(value=find_ffmpeg() or "")

ttk.Label(inputs, text="Drone RTSP / SRT / URL:").grid(row=0, column=0, sticky="w")
rtsp_entry = ttk.Entry(inputs, textvariable=rtsp_var, width=60)
rtsp_entry.grid(row=0, column=1, sticky="we", padx=6)

ttk.Label(inputs, text="Destination RTMP URL:").grid(row=1, column=0, sticky="w")
rtmp_entry = ttk.Entry(inputs, textvariable=rtmp_var, width=60)
rtmp_entry.grid(row=1, column=1, sticky="we", padx=6)

ttk.Label(inputs, text="ffmpeg path (optional):").grid(row=2, column=0, sticky="w")
ff_entry = ttk.Entry(inputs, textvariable=ffmpeg_var, width=60)
ff_entry.grid(row=2, column=1, sticky="we", padx=6)
ttk.Button(inputs, text="Browse", command=browse_ffmpeg).grid(row=2, column=2, sticky="we")

inputs.grid_columnconfigure(1, weight=1)

# Live view buttons
lv = ttk.Frame(right)
lv.pack(fill="x")
ttk.Button(lv, text="Live View", command=start_preview).pack(side="left", padx=(0,6))
ttk.Button(lv, text="Stop Live View", command=stop_preview).pack(side="left", padx=(0,6))
ttk.Button(lv, text="HDMI OUT Help", command=hdmi_out).pack(side="left")

# Bottom actions
bottom = ttk.Frame(main)
bottom.pack(fill="x", pady=8)
ttk.Button(bottom, text="Save Config", command=save_config).pack(side="left")
ttk.Button(bottom, text="Load Config", command=load_config).pack(side="left", padx=6)

# Hints
hint = ttk.Label(main, text="Hints: Example RTSP (varies by drone/controller). For YouTube Live, use RTMP from Live Control Room.", foreground="#555")
hint.pack(anchor="w", pady=(6,0))

load_config()
root.mainloop()
