
# Drone Live Broadcast (Windows)

This kit lets you create **DroneLive.exe** for Windows that can:
- Take a video feed from a drone/controller via **RTSP/SRT/URL**
- **Stream** to **RTMP** (YouTube/Facebook/Custom)
- Show **Live View** preview via ffplay (from ffmpeg) or VLC
- Provide **HDMI OUT** instructions for fullscreen on an external display

> No device driver is included here; supply your own feed URL from your drone/controller (DJI, Autel, etc.).

## Quick Start (One‑Click Build)

1. Install **Python 3.10+** (https://www.python.org/downloads/) and tick "Add to PATH".
2. Unzip this kit to a simple folder (e.g., `C:\DroneLive_Kit`).
3. (Optional) Download static **ffmpeg** for Windows and place **ffmpeg.exe** (and ffplay.exe) next to `app.py` or anywhere in PATH.
   - https://ffmpeg.org/download.html
4. Double‑click **`build.bat`** → it will create `dist\DroneLive.exe`.
5. Copy `DroneLive.exe` and `ffmpeg.exe`/`ffplay.exe` together to any machine and run.

## Using the App

- **Drone RTSP URL**: e.g. `rtsp://192.168.10.1:554/live` (your drone/controller may differ)
- **Destination RTMP URL**: e.g. YouTube Live "Stream URL + Key" as a single `rtmp://.../live2/<key>`
- **Start Stream**: begins ffmpeg publishing.
- **Live View**: opens preview (ffplay or VLC).
- **Stop Stream / Stop Live View**: stops the respective process.
- **HDMI OUT Help**: instructions to send preview fullscreen to an external monitor.

## Notes

- This is a **generic** tool that works with any source URL ffmpeg can open.
- Latency depends on your feed, network, and chosen sites.
- For DJI drones, you can typically get an RTMP push directly from DJI Fly or Controller. If you need RTSP from a controller or HDMI capture devices, consult your device manual.

## Build Troubleshooting

- If build fails, ensure `pip install pyinstaller tk` succeeded.
- If preview fails, install VLC (https://www.videolan.org/) or ensure `ffplay.exe` is present.
